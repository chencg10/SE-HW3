package BarberShopComponents;

public interface Payment {
	String amountToPay(int totalPayment);

}
